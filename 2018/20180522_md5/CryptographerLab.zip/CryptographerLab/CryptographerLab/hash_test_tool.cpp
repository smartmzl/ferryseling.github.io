/*
CryptographerLab
Created by Mengzelin 2018
For the purpose of practical learning & practical using.
Please visit https://smartmzl.github.io/
*/
#pragma once

#include "stdafx.h"
#include "stdio.h"
#include "stdafx.h"
#include "string.h"
#include <time.h>
#include <cstdlib> 

#include "md5.h"
#include "md5_standard.h"
#include "hash_test_tool.h"

// ����md5����
hash_test_tool* hash_test_tool::create() {
	// ��������
	hash_test_tool *obj = new hash_test_tool();
	return obj;
}
void hash_test_tool::destroy() {
	delete this;
}

hash_test_tool::hash_test_tool()
{
}


hash_test_tool::~hash_test_tool()
{
}

void hash_test_tool::run_speed(char* engine, char* str_length, char* repeat_times) {

	int str_length_ = std::atoi(str_length);
	int repeat_times_ = std::atoi(repeat_times);

	float start, time_spent;
	char* plain_text = new char[str_length_];
	memset(plain_text, 65, str_length_);

	char *cipher = new char[32];

	// ��ʼ����
	start = (float)clock();

	// ��������ѡ�񴴽�����
	int engine_ = 1;
	if (strncmp(engine, "self", 4) == 0) {
		// ����������md5�㷨
		md5* obj = md5::create();
		for (int i = 0; i < repeat_times_; i++)
		{
			obj->md5_str(plain_text, cipher);
		}
		obj->destroy();
		engine_ = 1;
	}
	else if (strncmp(engine, "std", 3) == 0) {
		// ��׼md5�㷨
		md5_standard* obj = md5_standard::create();
		for (int i = 0; i < repeat_times_; i++)
		{
			obj->md5_str(plain_text, cipher);
		}
		obj->destroy();
		engine_ = 2;
	}

	time_spent = ((float)clock() - start) / 1000;
	printf("Spent %f s for %u times, %.02f times per second, length: %d, use %d engine.\n", time_spent, repeat_times_, (float)repeat_times_ / time_spent, str_length_, engine_);

}

void hash_test_tool::run_validity(char* range_start, char* range_end) {

}